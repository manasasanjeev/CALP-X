import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

#code for streamlit

@st.cache
def train(nrows):
    data = pd.read_csv('train.csv', nrows=nrows)
    return data
@st.cache
def train_anno(nrows):
    data = pd.read_csv('train_annotations.csv',nrows=nrows)
    return data
#%matplotlib inline


dataset = train(1000)
annotations = train_anno(1000)

#st.subheader("Train Dataset")
#st.write(dataset)
#st.bar_chart(dataset['ETT - Abnormal'])
df=pd.read_csv("train.csv")
df1=pd.read_csv("train_annotations.csv")
st.title("Exploratory Data Analysis")


st.header("Overview of dataset1: ")
#st.bar_chart(df)
st.dataframe(train(5))
if st.button("Inference 1"):
    st.text("From the above graph we can infer that")
    st.text(" the dataset consists of X-ray id")
    st.text(" along with information about various catheters inserted and patients id")


st.header("Overview of dataset2: ")
st.dataframe(train_anno(5))
if st.button("Inference 2"):
    st.text("From the above graph we can infer that")
    st.text(" the dataset consists of unique X-ray id")
    st.text(" along with information about coordinates of catheters placed")

st.header("Number of X-ray images")
st.image("no_of_images.png")
if st.button("Inference 3"):
    st.text("This graph shows the different x-ray images in different number")
    st.text("We have greater noise as CVC-normal images are more and CVC-Abnormal Images are least")

st.header("Images of X-ray image's IDS")
st.image("images_for_ids.png")
if st.button("Inference 4"):
    st.text("This graph shows number of X-ray images for a given ID of image")
    st.text("Some patients have taken multiple X-ray images")

st.header("Sample X-ray image's IDS")
st.image("sample_xray.png")
if st.button("Inference 5"):
    st.text("This image is sample X-ray images for a some ID of image")

st.header("Images of X-ray for one ID")
st.image(["track1.png","track2.png"],width=300)
#st.image()
if st.button("Inference 6"):
    st.text("This image is sample X-ray images for an ID of image")
    st.text("This patient has multiple CVC catheter inserted in his/her lungs ")
    st.text("Contribution for Inference 4")


#st.header("Insight into the different values")
#st.text("Total Rows of Train Data is", len(df))
#st.text("Total Count of Each Variable in Train Data is", train.iloc[:, :-1].sum().sum())
#var_count = df.iloc[:, :-1].sum()
#st.text(var_count)

#fig, ax = plt.subplots(figsize=(10, 6))

#tmp = df['PatientID'].value_counts()
#st.text(tmp)
#sns.barplot(x = var_count.values, y = var_count.index, ax=ax)
#ax.tick_params(axis="x", labelsize=14)
#ax.tick_params(axis="y", labelsize=14)
#ax.set_xlabel("Number of Images", fontsize=15)
#ax.set_title("Distribution of Labels", fontsize=15)
#st.pyplot(fig)

